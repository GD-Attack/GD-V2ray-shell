#!/bin/bash
if yum update -y && yum install -y curl wget unzip tar openssl httpd firewalld;then
        echo "开始搭建翻墙服务器，服务器使用的是v2ray软件进行搭建"
        echo "开始执行任务..."

        systemctl enable --now httpd
        systemctl enable --now firewalld
        firewalld_enabled=$(systemctl is-enabled firewalld.service)
        firewalld_active=$(systemctl is-active firewalld.service)
        httpd_enabled=$(systemctl is-enabled httpd.service)
        httpd_activge=$(systemctl is-active httpd.service)
        if [ "${firewalld_enabled}" = 'enabled' -a "${firewalld_active}" = 'active' -a "${httpd_enabled}" = 'enabled' -a "${httpd_activge}" = 'active'  ];then
                firewall-cmd --permanent --add-port=80/tcp 2>/dev/null
                firewall-cmd --permanent --add-port=443/tcp 2>/dev/null
                firewall-cmd --reload
        else
                echo "防火墙或者apache服务没有安装，出现问题，检查环境之后重试"
                exit 2
        fi

        # 1. 检查是否为 root 用户
        if [ "$EUID" -ne 0 ]; then
            echo "错误：请使用 sudo 或 root 权限运行此脚本！"
            exit 3
        fi

        # 2. 检查并安装 curl (Rocky Linux 默认使用 dnf)
        if ! command -v curl &> /dev/null; then
            echo "正在安装 curl..."
            dnf install -y curl
        fi

        # 3. 下载官方脚本
        echo "正在下载 Xray 安装脚本..."
        curl -L https://github.com/XTLS/Xray-install/raw/main/install-release.sh -o install-release.sh

        # 4. 判断下载是否成功（文件是否存在且不为空）
        if [ ! -s install-release.sh ]; then
            echo "下载失败，请检查网络或 GitHub 连通性！"
            rm -f install-release.sh
            exit 4
        fi

        # 5. 赋予执行权限并运行安装
        echo "开始安装 Xray..."
        chmod +x install-release.sh
        ./install-release.sh install

        # 6. 清理临时文件
        rm -f install-release.sh
        echo "安装完成，临时文件已清理！"

        # 生成参数（自动赋值）
        export MY_UUID=$(/usr/local/bin/xray uuid)
        export KEYS=$(/usr/local/bin/xray x25519)
        export MY_PRIVATE_KEY=$(echo "$KEYS" | grep -i "Private" | awk -F': ' '{print $2}' | tr -d ' ')
        export MY_PUBLIC_KEY=$(echo "$KEYS" | grep -i "Public" | awk -F': ' '{print $2}' | tr -d ' ')
        export MY_SHORT_ID=$(openssl rand -hex 8)
        export MY_IP=$(curl -s https://api.ipify.org || curl -s https://ifconfig.me)
        if [ -n "${MY_UUID}" -a -n "${KEYS}" -a -n "${MY_PRIVATE_KEY}" -a -n "${MY_PUBLIC_KEY}" -a -n "${MY_SHORT_ID}" -a -n "${MY_IP}" ];then

                echo "=========================================="
                echo "服务器IP     : $MY_IP"
                echo "UUID         : $MY_UUID"
                echo "Public Key   : $MY_PUBLIC_KEY"
                echo "Short ID     : $MY_SHORT_ID"
                echo "=========================================="

        else
                echo "部分变量渲染失败，请重新审查代码或者是操作环境..."
                exit 5
        fi
        # 写入 Xray 配置并启动
        mkdir -p /usr/local/etc/xray
        if [ -d "/usr/local/etc/xray" ]; then
                echo "/usr/local/etc/xray目录存在,继续执行程序..."
                chmod a+x /root/v2ray_xray.sh
                /root/v2ray_xray.sh
                /usr/local/bin/xray run -test -config /usr/local/etc/xray/config.json
                systemctl daemon-reload
                systemctl enable --now xray
                systemctl restart xray
                xray_enabled=$(systemctl is-enabled xray)
                xray_active=$(systemctl is-active xray)
                if [ "${xray_enabled}" = 'enabled' -a "${xray_active}" = 'active' ];then
                        echo "成功启动xray，并成功实现xray开机自启"
                else
                        echo "启动失败，脚本停止执行..."
                        exit 7
                fi
        else
                echo "/usr/local/etc/xray目录不存在，中断程序的执行..."
                exit 6
        fi

        if [ -f "/root/v2ray_clash.sh" ]; then
                chmod a+x /root/v2ray_clash.sh
                /root/v2ray_clash.sh

                if [ -f "/var/www/html/clash.yaml" ]; then
                        chmod 644 /var/www/html/clash.yaml
                        restorecon -v /var/www/html/clash.yaml 2>/dev/null || true
                        chcon -R -t httpd_sys_content_t /var/www/html/ 2>/dev/null || true
                        echo "=========================================="
                        echo "Clash 订阅地址: http://${MY_IP}/clash.yaml"
                        echo "=========================================="
                else
                        echo "执行失败..."
                        exit 8
                fi
        else
                echo "文件不存在，无法执行..."
        fi

        # =================================================================
        # 【新增功能】：创建开机自动更新 Clash 订阅文件中 IP 地址的服务
        # =================================================================
        echo "正在配置开机自动更新公网 IP 的服务..."
        
        # 1. 创建更新 IP 的脚本文件
        cat > /usr/local/bin/update-clash-ip.sh << 'EOF'
#!/bin/bash
NEW_IP=""
# 循环尝试获取公网 IP，最多重试 30 次（防止开机网络未就绪）
for i in {1..30}; do
    NEW_IP=$(curl -s --connect-timeout 5 https://api.ipify.org || curl -s --connect-timeout 5 https://ifconfig.me)
    if [ -n "$NEW_IP" ]; then
        break
    fi
    sleep 2
done

# 如果成功获取到了新 IP 且 clash.yaml 文件存在，则自动替换其中的 server IP
if [ -n "$NEW_IP" ] && [ -f "/var/www/html/clash.yaml" ]; then
    sed -i -E "s/(server:[[:space:]]*[\"']).*([\"'])/\1${NEW_IP}\2/g; t; s/(server:[[:space:]]*)[^\"'].*/\1${NEW_IP}/g" /var/www/html/clash.yaml
fi
EOF

        # 赋予脚本执行权限
        chmod +x /usr/local/bin/update-clash-ip.sh

        # 2. 创建 systemd 服务文件
        cat > /etc/systemd/system/update-clash-ip.service << 'EOF'
[Unit]
Description=Auto Update Clash IP on Boot
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/update-clash-ip.sh

[Install]
WantedBy=multi-user.target
EOF

        # 3. 启用并加载开机自启服务
        systemctl daemon-reload
        systemctl enable update-clash-ip.service
        echo "开机自动更新 IP 服务配置成功！"

else
        echo "基础依赖软件安装失败，停止程序的执行..."
        exit 1
fi
