#!/bin/bash
cat > /var/www/html/clash.yaml << EOF
port: 7890
socks-port: 7891
mixed-port: 7890
allow-lan: true
mode: rule
log-level: info
ipv6: false
dns:
  enable: true
  enhanced-mode: fake-ip
  nameserver:
    - 223.5.5.5
    - 119.29.29.29
  fallback:
    - https://1.1.1.1/dns-query
    - https://8.8.8.8/dns-query
proxies:
  - name: "VMESS-节点"
    type: vmess
    server: "${MY_IP}"
    port: 443
    uuid: "${MY_UUID}"
    alterId: 0
    cipher: auto
    network: ws
    ws-opts:
      path: "/ray"
proxy-groups:
  - name: "🚀 节点选择"
    type: select
    proxies:
      - VMESS-节点
      - DIRECT
rules:
  - GEOIP,CN,DIRECT
  - MATCH,🚀 节点选择
EOF
